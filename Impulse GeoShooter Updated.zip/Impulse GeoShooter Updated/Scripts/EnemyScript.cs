using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyScript : MonoBehaviour
{
   
    NavMeshAgent agent;
    public int health;
    private Rigidbody2D rb;
    

    //Basic AI for enemy to chase the player
    [HideInInspector] public Transform player;
    public float speed;


    // if the hralth is less than 0, it will be killed 
    public void TakeDamage( int damageAmount)
    {
        health -= damageAmount;
        //rb.AddForce((player.transform.position - transform.position).normalized * speed);
        if(health <=0 )
        { 
            Destroy(gameObject);
        }
    }

    void Awake()
    {
        agent = GetComponent <NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Start()
    {
        //rb = GetComponent<Rigidbody2D>();
       player = GameObject.FindGameObjectWithTag("Player").transform;
    }

}
